import { create } from 'zustand'

export const useTimetableStore = create((set, get) => ({
  lessons: {},
  history: [],
  historyIndex: -1,

  addLesson: (key, lesson) => {
    const lessons = { ...get().lessons, [key]: lesson }
    const history = [...get().history.slice(0, get().historyIndex + 1), lessons]
    set({ lessons, history, historyIndex: history.length - 1 })
  },

  undo: () => {
    if (get().historyIndex > 0) {
      set({
        lessons: get().history[get().historyIndex - 1],
        historyIndex: get().historyIndex - 1
      })
    }
  },

  redo: () => {
    if (get().historyIndex < get().history.length - 1) {
      set({
        lessons: get().history[get().historyIndex + 1],
        historyIndex: get().historyIndex + 1
      })
    }
  }
}))
