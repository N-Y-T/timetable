import { useTimetableStore } from './store/timetableStore'

export default function App() {
  const { lessons, addLesson, undo, redo } = useTimetableStore()

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold mb-4">Timetable System</h1>

      <div className="flex gap-2 mb-4">
        <button onClick={undo} className="px-3 py-1 bg-gray-300 rounded">Undo</button>
        <button onClick={redo} className="px-3 py-1 bg-gray-300 rounded">Redo</button>
        <button
          onClick={() =>
            addLesson('Monday-1-10A', {
              subject: 'Math',
              teacher: 'Smith',
              room: 'A-101',
              class: '10A',
              color: 'bg-blue-500'
            })
          }
          className="px-3 py-1 bg-blue-500 text-white rounded"
        >
          Add lesson
        </button>
      </div>

      <pre className="bg-white p-4 rounded shadow text-sm">
        {JSON.stringify(lessons, null, 2)}
      </pre>
    </div>
  )
}
